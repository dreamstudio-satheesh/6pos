package com.u6amtech.six_pos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
